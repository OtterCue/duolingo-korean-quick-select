// 한글 초성 추출 유틸리티
const CHOSUNG_LIST = ['ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'];
const HANGUL_START = 0xAC00;
const HANGUL_END = 0xD7A3;

function getChosung(text) {
  let chosung = '';
  
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    
    if (code >= HANGUL_START && code <= HANGUL_END) {
      const chosungIndex = Math.floor((code - HANGUL_START) / 588);
      chosung += CHOSUNG_LIST[chosungIndex];
    } else if (CHOSUNG_LIST.includes(text[i])) {
      chosung += text[i];
    } else {
      chosung += text[i];
    }
  }
  
  return chosung;
}

class DuolingoKoreanQuickSelect {
  constructor() {
    this.currentInput = '';
    this.highlightedButtons = [];
    this.isActive = false;
    
    console.log('🎯 Duolingo Korean Quick Select 초기화 중...');
    
    // CSS 스타일 주입
    this.injectStyles();
    
    // 키보드 이벤트 리스너 - 여러 방법으로 등록
    const boundHandler = this.handleKeyDown.bind(this);
    
    // 1. capture 단계에서 가장 먼저 잡기
    window.addEventListener('keydown', boundHandler, true);
    document.addEventListener('keydown', boundHandler, true);
    document.body.addEventListener('keydown', boundHandler, true);
    
    // 2. 일반 이벤트도 등록
    window.addEventListener('keydown', boundHandler);
    document.addEventListener('keydown', boundHandler);
    
    // 3. keypress도 등록
    window.addEventListener('keypress', boundHandler, true);
    
    console.log('⌨️ 키보드 이벤트 리스너 등록 완료 (6개)');
    
    // 듀오링고의 다른 키보드 핸들러 확인 (디버깅용)
    setTimeout(() => {
      console.log('🔍 [디버깅] 현재 등록된 이벤트 리스너 확인:');
      console.log('  - window의 keydown 리스너 수:', 
                  getEventListeners(window).keydown?.length || '확인 불가');
      console.log('  - document의 keydown 리스너 수:', 
                  getEventListeners(document).keydown?.length || '확인 불가');
      console.log('  - body의 keydown 리스너 수:', 
                  getEventListeners(document.body).keydown?.length || '확인 불가');
    }, 1000);
    
    // 화면 변경 감지 (MutationObserver)
    this.observePageChanges();
    
    console.log('✅ Duolingo Korean Quick Select 활성화됨!');
  }
  
  injectStyles() {
    const style = document.createElement('style');
    style.textContent = `
      .korean-quick-select-highlight {
        background-color: #1cb0f6 !important;
        color: white !important;
        border-color: #1899d6 !important;
        transition: all 0.2s ease;
        transform: scale(1.05);
      }
      
      .korean-quick-select-exact-match {
        background-color: #58cc02 !important;
        color: white !important;
        border-color: #46a302 !important;
        box-shadow: 0 0 0 3px #58cc02 !important;
        transform: scale(1.1);
        animation: pulse 0.5s ease-in-out;
      }
      
      @keyframes pulse {
        0%, 100% { transform: scale(1.1); }
        50% { transform: scale(1.15); }
      }
    `;
    document.head.appendChild(style);
    console.log('✅ CSS 스타일 주입 완료');
  }
  
  observePageChanges() {
    const observer = new MutationObserver(() => {
      this.checkIfWordBankExists();
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    // 초기 체크
    this.checkIfWordBankExists();
    
    console.log('✅ 페이지 변화 감지 시작');
  }
  
  checkIfWordBankExists() {
    const wordBank = document.querySelector('[data-test="word-bank"]');
    const wasActive = this.isActive;
    
    // 단어 은행이 있고, 한글 버튼도 있어야 활성화
    if (wordBank) {
      const koreanButtons = this.getWordButtons();
      this.isActive = koreanButtons.length > 0;
      
      // 상태가 변경되었을 때만 로그
      if (wasActive !== this.isActive) {
        if (this.isActive) {
          console.log('✅ 단어 은행 발견! 한글 빠른 선택 활성화됨');
          console.log(`📝 한글 버튼 ${koreanButtons.length}개 발견:`, 
                      koreanButtons.map(b => b.textContent.trim()));
          console.log('🎮 이제 초성을 입력하세요! (예: ㅇ, ㄴ, ㄷ ...)');
        } else {
          console.log('⚠️ 단어 은행은 있지만 한글 버튼이 없음 - 비활성화');
        }
      }
    } else {
      this.isActive = false;
      if (wasActive !== this.isActive) {
        console.log('❌ 단어 은행 없음 - 대기 중...');
        // 입력 초기화
        if (this.currentInput !== '') {
          this.resetHighlight();
        }
      }
    }
  }
  
  handleKeyDown(event) {
    // 모든 키 입력을 일단 로그로 출력 (디버깅용)
    console.log(`🎹 [모든 키] key="${event.key}", code="${event.code}", target=${event.target.tagName}, type=${event.type}`);
    
    // 디버깅: 초성인지 확인
    if (CHOSUNG_LIST.includes(event.key)) {
      console.log(`✨ [초성 감지!] "${event.key}" - 이제 처리 시작`);
    }
    
    // input이나 textarea에서 타이핑 중이면 무시
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
      console.log(`⏭️ [건너뜀] INPUT/TEXTAREA에서 입력 - 무시`);
      return;
    }
    
    // 단어 은행이 없으면 비활성화
    if (!this.isActive) {
      if (CHOSUNG_LIST.includes(event.key)) {
        console.log(`❌ [비활성] 단어 은행이 없어서 비활성화됨`);
      }
      return;
    }
    
    // 여기까지 왔다면 단어 은행이 있고, INPUT/TEXTAREA가 아님
    console.log(`🟢 [활성 상태] isActive=${this.isActive}, 버튼=${this.getWordButtons().length}개`);
    
    // ESC: 초기화
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      console.log('🔄 [ESC] 초기화');
      this.resetHighlight();
      return;
    }
    
    // Backspace: 한 글자 삭제
    if (event.key === 'Backspace') {
      if (this.currentInput !== '') {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        this.currentInput = this.currentInput.slice(0, -1);
        console.log(`⬅️ [Backspace] 현재 입력: "${this.currentInput}"`);
        this.updateHighlight();
      }
      return;
    }
    
    // 한글 초성만 허용
    if (CHOSUNG_LIST.includes(event.key)) {
      console.log(`🎯 [초성 처리 시작] "${event.key}"`);
      
      // 이벤트 완전 차단
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      
      console.log(`🛑 [이벤트 차단] preventDefault, stopPropagation 완료`);
      
      this.currentInput += event.key;
      console.log(`✅ [입력 성공!] "${event.key}" 추가됨 - 현재: "${this.currentInput}"`);
      
      this.updateHighlight();
      
      return false; // 추가 차단
    } else {
      // 초성이 아닌 키
      console.log(`⚪ [일반 키] "${event.key}" - 초성 아님, 무시`);
    }
  }
  
  updateHighlight() {
    // 이전 하이라이트 제거
    this.clearHighlight();
    
    if (this.currentInput === '') {
      return;
    }
    
    // 모든 단어 버튼 가져오기
    const buttons = this.getWordButtons();
    
    if (buttons.length === 0) {
      console.warn('⚠️ 한글 버튼을 찾을 수 없습니다!');
      return;
    }
    
    const matchedButtons = [];
    let exactMatchButton = null;
    
    buttons.forEach(button => {
      const text = button.textContent.trim();
      const chosung = getChosung(text);
      
      console.log(`  "${text}" → 초성: "${chosung}"`);
      
      // 초성이 일치하는 버튼 찾기
      if (chosung.startsWith(this.currentInput)) {
        matchedButtons.push(button);
        button.classList.add('korean-quick-select-highlight');
        
        // 정확히 일치하는 버튼
        if (chosung === this.currentInput) {
          exactMatchButton = button;
          button.classList.remove('korean-quick-select-highlight');
          button.classList.add('korean-quick-select-exact-match');
        }
      }
    });
    
    this.highlightedButtons = matchedButtons;
    
    console.log(`🎯 입력: "${this.currentInput}", 매칭: ${matchedButtons.length}개`);
    
    if (matchedButtons.length > 0) {
      console.log('  매칭된 단어:', matchedButtons.map(b => b.textContent.trim()));
    }
    
    // 정확히 일치하는 버튼이 하나만 있으면 자동 클릭
    if (exactMatchButton && matchedButtons.length === 1) {
      console.log(`✨ 자동 선택: "${exactMatchButton.textContent.trim()}"`);
      setTimeout(() => {
        exactMatchButton.click();
        this.resetHighlight();
      }, 300);
    }
  }
  
  clearHighlight() {
    this.highlightedButtons.forEach(button => {
      button.classList.remove('korean-quick-select-highlight');
      button.classList.remove('korean-quick-select-exact-match');
    });
    this.highlightedButtons = [];
  }
  
  resetHighlight() {
    this.currentInput = '';
    this.clearHighlight();
    console.log('🔄 초기화 완료');
  }
  
  getWordButtons() {
    // 듀오링고 단어 버튼 선택자 - 여러 방법으로 시도
    let buttons = [];
    
    // 방법 1: data-test 속성으로 찾기 (가장 정확함)
    buttons = document.querySelectorAll('[data-test*="challenge-tap-token"]');
    
    // 방법 2: 만약 못 찾았다면 클래스로 찾기
    if (buttons.length === 0) {
      buttons = document.querySelectorAll('button[lang="ko"]');
    }
    
    // 방법 3: 그래도 없다면 단어 은행 내의 모든 버튼
    if (buttons.length === 0) {
      const wordBank = document.querySelector('[data-test="word-bank"]');
      if (wordBank) {
        buttons = wordBank.querySelectorAll('button');
      }
    }
    
    // 한글 버튼만 필터링
    const koreanButtons = Array.from(buttons).filter(button => {
      const lang = button.getAttribute('lang');
      const text = button.textContent;
      const hasKorean = /[가-힣]/.test(text);
      
      // lang="ko" 속성이 있거나, 한글이 포함된 버튼만 선택
      return lang === 'ko' || hasKorean;
    });
    
    return koreanButtons;
  }
}

// 페이지 로드 시 초기화
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log('📄 DOM 로드 완료 - 확장 프로그램 시작');
    new DuolingoKoreanQuickSelect();
  });
} else {
  console.log('📄 DOM 이미 로드됨 - 확장 프로그램 시작');
  new DuolingoKoreanQuickSelect();
}
