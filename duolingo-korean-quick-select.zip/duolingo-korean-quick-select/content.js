// 한글 초성 추출 유틸리티
const CHOSUNG_LIST = ['ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'];
const HANGUL_START = 0xAC00;
const HANGUL_END = 0xD7A3;

function getChosung(text) {
  let chosung = '';
  
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    
    if (code >= HANGUL_START && code <= HANGUL_END) {
      const chosungIndex = Math.floor((code - HANGUL_START) / 588);
      chosung += CHOSUNG_LIST[chosungIndex];
    } else if (CHOSUNG_LIST.includes(text[i])) {
      chosung += text[i];
    } else {
      chosung += text[i];
    }
  }
  
  return chosung;
}

class DuolingoKoreanQuickSelect {
  constructor() {
    this.currentInput = '';
    this.highlightedButtons = [];
    this.isActive = false;
    
    // CSS 스타일 주입
    this.injectStyles();
    
    // 키보드 이벤트 리스너
    document.addEventListener('keydown', this.handleKeyDown.bind(this));
    
    // 화면 변경 감지 (MutationObserver)
    this.observePageChanges();
    
    console.log('Duolingo Korean Quick Select 활성화됨');
  }
  
  injectStyles() {
    const style = document.createElement('style');
    style.textContent = `
      .korean-quick-select-highlight {
        background-color: #1cb0f6 !important;
        color: white !important;
        border-color: #1899d6 !important;
        transition: all 0.2s ease;
      }
      
      .korean-quick-select-exact-match {
        background-color: #58cc02 !important;
        color: white !important;
        border-color: #46a302 !important;
        box-shadow: 0 0 0 2px #58cc02 !important;
      }
    `;
    document.head.appendChild(style);
  }
  
  observePageChanges() {
    const observer = new MutationObserver(() => {
      this.checkIfWordBankExists();
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
  
  checkIfWordBankExists() {
    const wordBank = document.querySelector('[data-test="word-bank"]');
    this.isActive = wordBank !== null;
  }
  
  handleKeyDown(event) {
    // 단어 은행이 없으면 비활성화
    if (!this.isActive) {
      this.currentInput = '';
      return;
    }
    
    // input이나 textarea에서 타이핑 중이면 무시
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
      return;
    }
    
    // ESC: 초기화
    if (event.key === 'Escape') {
      this.resetHighlight();
      return;
    }
    
    // Backspace: 한 글자 삭제
    if (event.key === 'Backspace') {
      event.preventDefault();
      this.currentInput = this.currentInput.slice(0, -1);
      this.updateHighlight();
      return;
    }
    
    // 한글 초성만 허용
    if (CHOSUNG_LIST.includes(event.key)) {
      event.preventDefault();
      this.currentInput += event.key;
      this.updateHighlight();
    }
  }
  
  updateHighlight() {
    // 이전 하이라이트 제거
    this.clearHighlight();
    
    if (this.currentInput === '') {
      return;
    }
    
    // 모든 단어 버튼 가져오기
    const buttons = this.getWordButtons();
    const matchedButtons = [];
    let exactMatchButton = null;
    
    buttons.forEach(button => {
      const text = button.textContent.trim();
      const chosung = getChosung(text);
      
      // 초성이 일치하는 버튼 찾기
      if (chosung.startsWith(this.currentInput)) {
        matchedButtons.push(button);
        button.classList.add('korean-quick-select-highlight');
        
        // 정확히 일치하는 버튼
        if (chosung === this.currentInput) {
          exactMatchButton = button;
          button.classList.remove('korean-quick-select-highlight');
          button.classList.add('korean-quick-select-exact-match');
        }
      }
    });
    
    this.highlightedButtons = matchedButtons;
    
    // 정확히 일치하는 버튼이 하나만 있으면 자동 클릭
    if (exactMatchButton && matchedButtons.length === 1) {
      setTimeout(() => {
        exactMatchButton.click();
        this.resetHighlight();
      }, 200);
    }
    
    console.log(`입력: "${this.currentInput}", 매칭: ${matchedButtons.length}개`);
  }
  
  clearHighlight() {
    this.highlightedButtons.forEach(button => {
      button.classList.remove('korean-quick-select-highlight');
      button.classList.remove('korean-quick-select-exact-match');
    });
    this.highlightedButtons = [];
  }
  
  resetHighlight() {
    this.currentInput = '';
    this.clearHighlight();
  }
  
  getWordButtons() {
    // 듀오링고 단어 버튼 선택자
    const buttons = document.querySelectorAll('[data-test*="challenge-tap-token"]');
    return Array.from(buttons).filter(button => {
      // 한글 버튼만 선택 (lang="ko" 속성 확인)
      return button.getAttribute('lang') === 'ko';
    });
  }
}

// 페이지 로드 시 초기화
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new DuolingoKoreanQuickSelect();
  });
} else {
  new DuolingoKoreanQuickSelect();
}
