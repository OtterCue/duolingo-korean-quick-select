// 영어 키보드 → 한글 초성 매핑 (QWERTY 자판 기준)
const KEY_TO_CHOSUNG = {
  // 왼손
  'q': 'ㅂ', 'Q': 'ㅃ',
  'w': 'ㅈ', 'W': 'ㅉ',
  'e': 'ㄷ', 'E': 'ㄸ',
  'r': 'ㄱ', 'R': 'ㄲ',
  't': 'ㅅ', 'T': 'ㅆ',
  
  // 오른손
  'y': 'ㅛ',
  'u': 'ㅕ',
  'i': 'ㅑ',
  'o': 'ㅐ',
  'p': 'ㅔ',
  
  // 가운데줄
  'a': 'ㅁ',
  's': 'ㄴ',
  'd': 'ㅇ',
  'f': 'ㄹ',
  'g': 'ㅎ',
  
  'h': 'ㅗ',
  'j': 'ㅓ',
  'k': 'ㅏ',
  'l': 'ㅣ',
  
  // 아래줄
  'z': 'ㅋ',
  'x': 'ㅌ',
  'c': 'ㅊ',
  'v': 'ㅍ'
};

// 한글 초성 리스트
const CHOSUNG_LIST = ['ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'];
const HANGUL_START = 0xAC00;
const HANGUL_END = 0xD7A3;

function getChosung(text) {
  let chosung = '';
  
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    
    if (code >= HANGUL_START && code <= HANGUL_END) {
      const chosungIndex = Math.floor((code - HANGUL_START) / 588);
      chosung += CHOSUNG_LIST[chosungIndex];
    } else if (CHOSUNG_LIST.includes(text[i])) {
      chosung += text[i];
    } else {
      chosung += text[i];
    }
  }
  
  return chosung;
}

class DuolingoKoreanQuickSelect {
  constructor() {
    this.currentInput = '';
    this.highlightedButtons = [];
    this.isActive = false;
    
    console.log('🎯 Duolingo Korean Quick Select 초기화 중...');
    console.log('💡 영어 키보드 → 한글 자판 매핑 모드!');
    console.log('   예: r = ㄱ, s = ㄴ, d = ㅇ, f = ㄹ');
    
    this.injectStyles();
    
    // 키보드 이벤트 리스너
    document.addEventListener('keydown', this.handleKeyDown.bind(this), true);
    
    this.observePageChanges();
    
    console.log('✅ Duolingo Korean Quick Select 활성화됨!');
  }
  
  injectStyles() {
    const style = document.createElement('style');
    style.textContent = `
      .korean-quick-select-highlight {
        background-color: #1cb0f6 !important;
        color: white !important;
        border-color: #1899d6 !important;
        transition: all 0.2s ease;
        transform: scale(1.05);
      }
      
      .korean-quick-select-exact-match {
        background-color: #58cc02 !important;
        color: white !important;
        border-color: #46a302 !important;
        box-shadow: 0 0 0 3px #58cc02 !important;
        transform: scale(1.1);
        animation: pulse 0.5s ease-in-out;
      }
      
      @keyframes pulse {
        0%, 100% { transform: scale(1.1); }
        50% { transform: scale(1.15); }
      }
      
      /* 화면 우측 하단 입력 표시 */
      .kqs-input-display {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: rgba(28, 176, 246, 0.95);
        color: white;
        padding: 15px 25px;
        border-radius: 12px;
        font-family: 'Courier New', monospace;
        font-size: 24px;
        font-weight: bold;
        z-index: 999999;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        pointer-events: none;
        opacity: 0;
        transform: translateY(10px);
        transition: all 0.3s ease;
      }
      
      .kqs-input-display.visible {
        opacity: 1;
        transform: translateY(0);
      }
      
      .kqs-input-display .kqs-help {
        font-size: 11px;
        opacity: 0.8;
        margin-top: 5px;
      }
    `;
    document.head.appendChild(style);
    console.log('✅ CSS 스타일 주입 완료');
  }
  
  createInputDisplay() {
    if (this.inputDisplay) return;
    
    this.inputDisplay = document.createElement('div');
    this.inputDisplay.className = 'kqs-input-display';
    this.inputDisplay.innerHTML = `
      <div class="kqs-text">대기 중...</div>
      <div class="kqs-help">r=ㄱ, s=ㄴ, d=ㅇ, f=ㄹ</div>
    `;
    document.body.appendChild(this.inputDisplay);
  }
  
  updateInputDisplay() {
    if (!this.inputDisplay) this.createInputDisplay();
    
    const textEl = this.inputDisplay.querySelector('.kqs-text');
    
    if (this.currentInput) {
      textEl.textContent = this.currentInput;
      this.inputDisplay.classList.add('visible');
    } else {
      setTimeout(() => {
        this.inputDisplay.classList.remove('visible');
      }, 1000);
    }
  }
  
  observePageChanges() {
    const observer = new MutationObserver(() => {
      this.checkIfWordBankExists();
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    this.checkIfWordBankExists();
    console.log('✅ 페이지 변화 감지 시작');
  }
  
  checkIfWordBankExists() {
    const wordBank = document.querySelector('[data-test="word-bank"]');
    const wasActive = this.isActive;
    
    if (wordBank) {
      const koreanButtons = this.getWordButtons();
      this.isActive = koreanButtons.length > 0;
      
      if (wasActive !== this.isActive) {
        if (this.isActive) {
          console.log('✅ 단어 은행 발견! 한글 빠른 선택 활성화됨');
          console.log(`📝 한글 버튼 ${koreanButtons.length}개 발견:`, 
                      koreanButtons.map(b => b.textContent.trim()));
          console.log('⌨️ 영어 자판으로 입력하세요! (r=ㄱ, s=ㄴ, d=ㅇ, f=ㄹ ...)');
        }
      }
    } else {
      this.isActive = false;
      if (wasActive !== this.isActive && this.currentInput !== '') {
        this.resetHighlight();
      }
    }
  }
  
  handleKeyDown(event) {
    // 단어 은행이 없으면 비활성화
    if (!this.isActive) return;
    
    const key = event.key;
    
    // ESC: 초기화
    if (key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      console.log('🔄 ESC - 초기화');
      this.resetHighlight();
      return;
    }
    
    // Backspace: 한 글자 삭제
    if (key === 'Backspace') {
      if (this.currentInput !== '') {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        this.currentInput = this.currentInput.slice(0, -1);
        console.log(`⬅️ Backspace - 현재: "${this.currentInput}"`);
        this.updateHighlight();
        this.updateInputDisplay();
      }
      return;
    }
    
    // 영어 키 → 한글 초성 변환
    if (KEY_TO_CHOSUNG[key]) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      
      const chosung = KEY_TO_CHOSUNG[key];
      this.currentInput += chosung;
      
      console.log(`✅ "${key}" → "${chosung}" 입력! 현재: "${this.currentInput}"`);
      
      this.updateHighlight();
      this.updateInputDisplay();
      
      return false;
    }
    
    // 한글 초성 직접 입력 (한글 모드일 때)
    if (CHOSUNG_LIST.includes(key)) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      
      this.currentInput += key;
      console.log(`✅ 한글 "${key}" 직접 입력! 현재: "${this.currentInput}"`);
      
      this.updateHighlight();
      this.updateInputDisplay();
      
      return false;
    }
  }
  
  updateHighlight() {
    this.clearHighlight();
    
    if (this.currentInput === '') {
      return;
    }
    
    const buttons = this.getWordButtons();
    
    if (buttons.length === 0) {
      console.warn('⚠️ 한글 버튼을 찾을 수 없습니다!');
      return;
    }
    
    const matchedButtons = [];
    let exactMatchButton = null;
    
    buttons.forEach(button => {
      const text = button.textContent.trim();
      const chosung = getChosung(text);
      
      if (chosung.startsWith(this.currentInput)) {
        matchedButtons.push(button);
        button.classList.add('korean-quick-select-highlight');
        
        if (chosung === this.currentInput) {
          exactMatchButton = button;
          button.classList.remove('korean-quick-select-highlight');
          button.classList.add('korean-quick-select-exact-match');
        }
      }
    });
    
    this.highlightedButtons = matchedButtons;
    
    console.log(`🎯 입력: "${this.currentInput}", 매칭: ${matchedButtons.length}개`);
    
    if (matchedButtons.length > 0) {
      console.log('  매칭된 단어:', matchedButtons.map(b => b.textContent.trim()));
    }
    
    // 정확히 일치하는 버튼이 하나만 있으면 자동 클릭
    if (exactMatchButton && matchedButtons.length === 1) {
      console.log(`✨ 자동 선택: "${exactMatchButton.textContent.trim()}"`);
      setTimeout(() => {
        exactMatchButton.click();
        this.resetHighlight();
      }, 300);
    }
  }
  
  clearHighlight() {
    this.highlightedButtons.forEach(button => {
      button.classList.remove('korean-quick-select-highlight');
      button.classList.remove('korean-quick-select-exact-match');
    });
    this.highlightedButtons = [];
  }
  
  resetHighlight() {
    this.currentInput = '';
    this.clearHighlight();
    this.updateInputDisplay();
    console.log('🔄 초기화 완료');
  }
  
  getWordButtons() {
    let buttons = [];
    
    buttons = document.querySelectorAll('[data-test*="challenge-tap-token"]');
    
    if (buttons.length === 0) {
      buttons = document.querySelectorAll('button[lang="ko"]');
    }
    
    if (buttons.length === 0) {
      const wordBank = document.querySelector('[data-test="word-bank"]');
      if (wordBank) {
        buttons = wordBank.querySelectorAll('button');
      }
    }
    
    const koreanButtons = Array.from(buttons).filter(button => {
      const lang = button.getAttribute('lang');
      const text = button.textContent;
      const hasKorean = /[가-힣]/.test(text);
      
      return lang === 'ko' || hasKorean;
    });
    
    return koreanButtons;
  }
}

// 페이지 로드 시 초기화
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log('📄 DOM 로드 완료 - 확장 프로그램 시작');
    new DuolingoKoreanQuickSelect();
  });
} else {
  console.log('📄 DOM 이미 로드됨 - 확장 프로그램 시작');
  new DuolingoKoreanQuickSelect();
}
